
Factory.define :puppy do |f|
  f.name 'Buddy'
  f.breed 'Golden Retriever'
  f.description 'Best dog in the world'
  f.gender 'Male'
  f.image_url 'buddy.png'
  f.fees 99.99
end

