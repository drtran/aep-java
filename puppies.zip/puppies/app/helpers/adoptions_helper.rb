module AdoptionsHelper
end
