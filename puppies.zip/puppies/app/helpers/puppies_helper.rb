module PuppiesHelper
end
