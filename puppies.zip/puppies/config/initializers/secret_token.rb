# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Puppies::Application.config.secret_token = 'c91413712a22b3f6d2630e9e7194443e17218d296b2d3a234d79d2c137649fc3c6198f87f0d1c8319b5ac009f57d87e8430f25a507b693620aa238c2b4715577'
